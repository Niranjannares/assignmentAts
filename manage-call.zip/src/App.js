import React, { useState } from 'react';
import {
  AppBar, Toolbar, Avatar, IconButton, Box, Typography, Grid, TextField, Button,
  Select, MenuItem, Checkbox, ListItemText, InputLabel, FormControl
} from '@mui/material';
import { Table, TableBody, TableCell, TableContainer, TableHead, TableRow, Paper } from '@mui/material';
import { DatePicker } from '@mui/x-date-pickers/DatePicker';
import { LocalizationProvider } from '@mui/x-date-pickers/LocalizationProvider';
import { AdapterDateFns } from '@mui/x-date-pickers/AdapterDateFns';
import FileDownloadOutlinedIcon from '@mui/icons-material/FileDownloadOutlined';
import FilterListOutlinedIcon from '@mui/icons-material/FilterListOutlined';
import MoreVertIcon from '@mui/icons-material/MoreVert';
import Menu from '@mui/material/Menu';
import PauseCircleFilledOutlinedIcon from '@mui/icons-material/PauseCircleFilledOutlined';
import PlayCircleFilledOutlinedIcon from '@mui/icons-material/PlayCircleFilledOutlined';
import DownloadForOfflineSharpIcon from '@mui/icons-material/DownloadForOfflineSharp';

function App() {
  const [selectedItems, setSelectedItems] = useState([]);
  const [selectedDate, setSelectedDate] = useState(null);
  const [data, setData] = useState([
    {
      action: 'View',
      phoneNumber: '1234567890',
      callDate: '2023-01-01',
      recordingFile: 'file1.mp3',
      respCode: '200',
      campName: 'Atria',
      agentId: 'A123',
    },
    {
      action: 'Download',
      phoneNumber: '0987654321',
      callDate: '2023-02-01',
      recordingFile: 'file2.mp3',
      respCode: '400',
      campName: 'Titania',
      agentId: 'T123',
    },
  ]);

  const options = ['Play', 'Pause', 'Save'];
  const ITEM_HEIGHT = 28;
  const [anchorEl, setAnchorEl] = useState(null);
  const open = Boolean(anchorEl);
  
  // Audio state and logic
  const [audio, setAudio] = useState(null);
  const [isPlaying, setIsPlaying] = useState(false);

  const handleChange = (event) => {
    setSelectedItems(event.target.value);
  };

  const handleDateChange = (newDate) => {
    setSelectedDate(newDate);
  };

  const handleMenuClick = (event) => {
    setAnchorEl(event.currentTarget);
  };

  const handleMenuClose = () => {
    setAnchorEl(null);
  };
  const handleButtonClick = () => {
    alert('Button clicked!');
  };

    // Function to trigger the download
    const handleCsvDownload = () => {
      const csvContent = [
        ['Phone Number', 'Call Date', 'Recording File'],
        ['1234567890', '2023-01-01', 'file1.mp3'],
        ['0987654321', '2023-02-01', 'file2.mp3'],
        // Add more rows as needed
      ]
        .map(row => row.join(',')) // Convert rows to comma-separated strings
        .join('\n'); // Join rows with newlines
    
      const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
      const link = document.createElement('a');
      link.href = URL.createObjectURL(blob); // Create a URL for the Blob
      link.download = 'data.csv'; // Set the download filename
      link.click(); // Trigger the download
    };

  // Reusable Date Picker Component
  const renderDatePicker = (label) => (
    <LocalizationProvider dateAdapter={AdapterDateFns}>
      <Box sx={{ width: 300, marginTop: 2, marginBottom: 3 }}>
        <DatePicker
          label={label}
          value={selectedDate}
          onChange={handleDateChange}
          minDate={new Date('2022-01-01')}
          maxDate={new Date('2023-12-31')}
          renderInput={(params) => <TextField {...params} fullWidth />}
        />
      </Box>
    </LocalizationProvider>
  );

  // Function to play sound
  const playSound = () => {
    if (audio && !audio.paused) {
      audio.pause();  // Pause the current audio if it's playing
      audio.currentTime = 0;  // Reset the audio to the beginning
    }

  //   const audio = new Audio(filePath);
  // audio.play().catch((error) => {
  //   console.error("Error playing sound:", error);
  // });
  
    const audioPath = `/audio/sample3.mp3`; // Assuming audio files are in the public/audio/ folder
    const newAudio = new Audio(audioPath);  // Create a new Audio object with the correct file path
    setAudio(newAudio);
    
    newAudio.onerror = () => {
      console.error("Error loading audio file. Please check the file path.");
    };
    
    newAudio.play();  // Play the audio
    setIsPlaying(true);  // Set the playing state to true
  };

  // Function to pause sound
  const pauseSound = () => {
    if (audio) {
      audio.pause();  // Pause the audio
      setIsPlaying(false);  // Set the playing state to false
    }
  };

  return (
    <div>
      <Toolbar>
        <Box sx={{ flexGrow: 1 }} />
        <IconButton edge="end" color="inherit">
          <Avatar alt="Profile Picture" src="/path/to/profile-image.jpg" />
        </IconButton>
      </Toolbar>

      <main style={{ padding: '10px' }}>
        <Box sx={{ flexGrow: 1, backgroundColor: 'black', color: 'white', padding: '8px' }}>
          <Typography variant="h6">Manage Call Recording</Typography>
        </Box>

        <Box sx={{ border: '2px solid black', borderRadius: '8px', padding: '16px', marginTop: '20px' }}>
          <Grid container spacing={2}>
            <Grid item xs={3}>
              <Typography variant="h6">Campaign Id</Typography>
              <Box sx={{ width: 300, marginTop: 2, marginBottom: 3 }}>
                <FormControl fullWidth>
                  <InputLabel>Select...</InputLabel>
                  <Select
                    label="Select..."
                    multiple
                    value={selectedItems}
                    onChange={handleChange}
                    renderValue={(selected) => selected.join(', ')}
                    sx={{ height: 40, fontSize: '0.875rem', padding: '10px' }}
                  >
                    {options.map((option) => (
                      <MenuItem key={option} value={option}>
                        <Checkbox checked={selectedItems.includes(option)} />
                        <ListItemText primary={option} />
                      </MenuItem>
                    ))}
                  </Select>
                </FormControl>
              </Box>
            </Grid>

            <Grid item xs={3}>
              <Typography variant="h6">Call Date From</Typography>
              {renderDatePicker('Pick a date')}
            </Grid>

            <Grid item xs={3}>
              <Typography variant="h6">Call Date To</Typography>
              {renderDatePicker('Pick a date')}
            </Grid>
          </Grid>

          <Grid container spacing={2}>
            <Grid item xs={3}>
              <Typography variant="h6">Phone Number</Typography>
              <TextField label="NA" fullWidth variant="outlined" sx={{ marginTop: 1 }} />
            </Grid>

            <Grid item xs={3}>
              <Typography variant="h6">Volunteer Number</Typography>
              <TextField label="NA" fullWidth variant="outlined" sx={{ marginTop: 1 }} />
            </Grid>

            <Grid item xs={3}>
              <Typography variant="h6">Agent Id</Typography>
              <TextField label="NA" fullWidth variant="outlined" sx={{ marginTop: 1 }} />
            </Grid>

            <Grid item xs={3}>
              <Typography variant="h6">Response Code</Typography>
              <TextField label="NA" fullWidth variant="outlined" sx={{ marginTop: 1 }} />
            </Grid>
          </Grid>
        </Box>
        <Grid container spacing={3} sx={{ padding: 2 }}>
          <Grid item xs={12}>
            <Box sx={{ display: 'flex', justifyContent: 'flex-end', gap: 2, marginTop: 2 }}>
              <Button
                variant="contained"
                onClick={handleButtonClick}
                sx={{
                  backgroundColor: 'black',
                  color: 'white',
                  '&:hover': { backgroundColor: 'gray' },
                }}
              >
                Search
              </Button>

              <Button
                variant="contained"
                onClick={handleButtonClick}
                sx={{
                  backgroundColor: 'black',
                  color: 'white',
                  '&:hover': { backgroundColor: 'gray' },
                }}
              >
                Cancel
              </Button>
            </Box>
          </Grid>
        </Grid>
        <Box sx={{ display: 'flex', justifyContent: 'flex-end', marginBottom: 2 }}>
          {/* Filter TextField */}
          <Button
            variant="contained"
            sx={{ marginLeft: 2 }}
            startIcon={<FilterListOutlinedIcon />}
          >
            Filter
          </Button>
          {/* Download Button with Icon */}
          <Button
            variant="contained"
            sx={{ marginLeft: 2 }}
            startIcon={<FileDownloadOutlinedIcon />}
            onClick={handleCsvDownload}
          >
            EXPORT
          </Button>
        </Box>

        {/* for data table section */}
        <Grid container spacing={2}>
          <TableContainer component={Paper}>
            <Table sx={{ minWidth: 650 }} aria-label="simple table">
              <TableHead>
                <TableRow>
                  <TableCell>Action</TableCell>
                  <TableCell>Phone Number</TableCell>
                  <TableCell>Call Date</TableCell>
                  <TableCell>Recording File</TableCell>
                  <TableCell>Resp code</TableCell>
                  <TableCell>Camp Name</TableCell>
                  <TableCell>Agent Id</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {data.map((row, index) => (
                  <TableRow key={index}>
                    <TableCell>
                      <IconButton
                        aria-label="more"
                        id="long-button"
                        aria-controls={open ? 'long-menu' : undefined}
                        aria-expanded={open ? 'true' : undefined}
                        aria-haspopup="true"
                        onClick={handleMenuClick}
                      >
                        <MoreVertIcon />
                      </IconButton>
                      <Menu
                        id="long-menu"
                        MenuListProps={{ 'aria-labelledby': 'long-button' }}
                        anchorEl={anchorEl}
                        open={open}
                        onClose={handleMenuClose}
                        slotProps={{
                          paper: {
                            style: { maxHeight: ITEM_HEIGHT * 4.5, width: '20ch' },
                          },
                        }}
                      >
                        {/* Play Icon + Text MenuItem */}
                        <MenuItem onClick={() => playSound(row.recordingFile)}>
                          <PlayCircleFilledOutlinedIcon sx={{ marginRight: 1 }} />
                          Play
                        </MenuItem>
                        <MenuItem onClick={pauseSound}>
                          <PauseCircleFilledOutlinedIcon sx={{ marginRight: 1 }} />
                          Pause
                        </MenuItem>
                        <MenuItem onClick={handleMenuClose}>
                          <DownloadForOfflineSharpIcon sx={{ marginRight: 1 }} />
                          Save
                        </MenuItem>
                      </Menu>
                    </TableCell>
                    <TableCell>{row.phoneNumber}</TableCell>
                    <TableCell>{row.callDate}</TableCell>
                    <TableCell>{row.recordingFile}</TableCell>
                    <TableCell>{row.respCode}</TableCell>
                    <TableCell>{row.campName}</TableCell>
                    <TableCell>{row.agentId}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </TableContainer>
        </Grid>
      </main>
    </div>
  );
}

export default App;
